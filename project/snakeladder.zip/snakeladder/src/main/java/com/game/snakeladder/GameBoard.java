/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.snakeladder;

import java.util.Random;

/**
 *
 * @author TryTry
 */
public class GameBoard {
    public int maxSteps = 50;
    public int curStep = 0;
    public int highScore = 0;
    public int generateDiceNum()
    {
      Random rand = new Random(); 
      int upperbound = 6;
      int int_random = rand.nextInt(upperbound); 
      return int_random + 1;
    }
    public void initialize()
    {
        curStep = 0;
    }
    public String getQuestion()
    {
        String result = "";
        switch(this.curStep)
        {
            case 3:
                result = "how many access specifiers are there in java?";
                break;
            case 4:
                result = "How many types of loops are there in java?";
                break;
            case 6:
                result = "for (;;){..} is an infinite loop?";
                break;
            case 8:
                result = "while(){} is an infinite loop?";
                break;
            case 9:
                result = " What is Final Keyword in Java? ";
                break;
            case 11:
                result = "What operator is 'status = (rank == 1) ? \"Done\" : \"Pending\";'?";
                break;
            case 12:
                result = "Which class can you use to generate random numbers in Java?";
                break;
            case 14:
                result = "What is default switch case?";
                break;
            case 16:
                result = "What's the base class in Java from which all classes are derived?";
                break;
            case 19:
                result = "Can main() method in Java can return any data?";
                break;
            case 21:
                result = " Can we declare a class as Abstract without having any abstract method?";
                break;
            case 23:
                result = "What is the keyword to import java packages?";
                break;
            case 24:
                result = "Can we declare the main method of our class as private?";
                break;
            case 26:
                result = "Can a class have multiple constructors?";
                break;
            case 29:
                result = "Can we override static methods of a class?";
                break;
            case 33:
                result = " Is String a data type in java?";
                break;
            case 37:
                result = "How many ways of implementing multi-threading are in Java?";
                break;
            case 41:
                result = "Can a class be a super class and a sub-class at the same time?";
                break;
            case 45:
                result = "Can we call the constructor of a class more than once for an object?";
                break;
            case 47:
                result = " Which types of exceptions are caught at compile time?";
                break;                
            default:
        }
        return result;
    }
    public String getAnswer()
    {
        String result = "";
        switch(this.curStep)
        {
            case 3:
                result = "4";
                break;
            case 4:
                result = "3";
                break;
            case 6:
                result = "yes";
                break;
            case 8:
                result = "no";
                break;
            case 9:
                result = "final";
                break;
            case 11:
                result = "ternary operator";
                break;
            case 12:
                result = "Random";
                break;
            case 14:
                result = "default:";
                break;
            case 16:
                result = "java.lang.object";
                break;
            case 19:
                result = "no";
                break;
            case 21:
                result = "yes";
                break;
            case 23:
                result = "import";
                break;
            case 24:
                result = "no";
                break;
            case 26:
                result = "yes";
                break;
            case 29:
                result = "no";
                break;
            case 33:
                result = "no";
                break;
            case 37:
                result = "2";
                break;
            case 41:
                result = "yes";
                break;
            case 45:
                result = "no";
                break;
            case 47:
                result = "Checked exceptions";
                break;                
            default:
        }
        return result;
    }
}
