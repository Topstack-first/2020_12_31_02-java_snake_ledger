/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.snakeladder;

import java.util.Scanner;

/**
 *
 * @author TryTry
 */
public class Main {
    
    public static void main(String[] args) 
    {
        GameBoard gameBoard = new GameBoard();
        Scanner scnr = new Scanner(System.in);
        while(true)
        {
            print("Select your choice for game:");
            print("1.Play");
            print("2.Rules");
            print("3.High Score");
            print("4.Exit");
            
            int choice = scnr.nextInt();
            
            if(choice == 4)
            {
                break;
            }
            else if(choice == 3)
            {
                print("High Score : "+gameBoard.highScore);
                print("");
                continue;
            }
            else if(choice == 2)
            {
                print("Rules : ");
                print("throw dice, and then move with dice number");
                print("if have a question, you write answer.");
                print("If answer is true, you can continue.");
                print("but if answer is false, game over.");
            }
            else if(choice == 1)
            {
                boolean gameResult = true;
                while(gameBoard.curStep <= gameBoard.maxSteps)
                {
                    print("throw dice (enter) ");
                    String empty = scnr.nextLine();
                    
                    int diceNum = gameBoard.generateDiceNum();
                    print("dice number:"+diceNum);
                    
                    gameBoard.curStep += diceNum;
                    
                    String question = gameBoard.getQuestion();
                    
                    if(!question.equals(""))
                    {
                        print("question: "+question);
                        print("write answer: ");
                        
                        String answer = gameBoard.getAnswer();
                        String userAnswer = scnr.nextLine();
                        if(!userAnswer.contains(answer))
                        {
                            print("answer is not correct.");
                            print("game over");
                            gameResult = false;
                            break;
                        }
                    }
                    
                    print("current score:"+gameBoard.curStep);
                    print("");
                }
                if(gameResult)
                {
                    print("game successful!");
                }
                
            }
            print("");
            print("");
        }
        
    }
    private static void print(String str)
    {
        System.out.print(str+"\n");
    }
}
